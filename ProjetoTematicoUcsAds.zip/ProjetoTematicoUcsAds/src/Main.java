import View.InterfaceDeUsuario;

public class Main {
    public static void main(String[] args) {
        InterfaceDeUsuario inter = new InterfaceDeUsuario();
        inter.mostrarMenuPrincipal();
    }
}