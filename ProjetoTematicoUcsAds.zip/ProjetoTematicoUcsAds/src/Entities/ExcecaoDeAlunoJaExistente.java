package Entities;

public class ExcecaoDeAlunoJaExistente extends Exception {
    public ExcecaoDeAlunoJaExistente(String message) {
        super(message);
    }
}